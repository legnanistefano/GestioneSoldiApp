import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel: TransactionsViewModel
    @State private var showingAdd = false

    var body: some View {
        VStack {
            HStack {
                VStack(alignment: .leading) {
                    Text("Entrate: ")
                    Text("Uscite: ")
                }
                VStack(alignment: .trailing) {
                    Text("€ \(viewModel.totalIncome, specifier: "%.2f")")
                        .foregroundColor(.green)
                    Text("€ \(viewModel.totalExpense, specifier: "%.2f")")
                        .foregroundColor(.red)
                }
            }
            .padding()

            List(viewModel.transactions) { t in
                HStack {
                    VStack(alignment: .leading) {
                        Text(t.title)
                        Text(t.date, style: .date)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                    Text("€ \(t.amount, specifier: "%.2f")")
                        .foregroundColor(t.isIncome ? .green : .red)
                }
            }
        }
        .navigationTitle("Gestione Soldi")
        .toolbar {
            Button("+") { showingAdd = true }
        }
        .sheet(isPresented: $showingAdd) {
            AddTransactionView().environmentObject(viewModel)
        }
    }
}
