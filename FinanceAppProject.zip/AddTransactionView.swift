import SwiftUI

struct AddTransactionView: View {
    @EnvironmentObject var viewModel: TransactionsViewModel
    @Environment(\.dismiss) var dismiss

    @State private var title = ""
    @State private var amount = ""
    @State private var isIncome = true

    var body: some View {
        NavigationView {
            Form {
                TextField("Titolo", text: $title)
                TextField("Importo", text: $amount)
                    .keyboardType(.decimalPad)

                Picker("Tipo", selection: $isIncome) {
                    Text("Entrata").tag(true)
                    Text("Uscita").tag(false)
                }
                .pickerStyle(.segmented)
            }
            .navigationTitle("Aggiungi Movimento")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annulla") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salva") {
                        if let value = Double(amount) {
                            viewModel.addTransaction(title: title, amount: value, isIncome: isIncome)
                            dismiss()
                        }
                    }
                }
            }
        }
    }
}
