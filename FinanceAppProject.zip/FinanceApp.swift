import SwiftUI

@main
struct FinanceApp: App {
    @StateObject private var viewModel = TransactionsViewModel()

    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView().environmentObject(viewModel)
            }
        }
    }
}
