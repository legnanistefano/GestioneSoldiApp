import Foundation

struct Transaction: Identifiable {
    let id = UUID()
    let title: String
    let amount: Double
    let date: Date
    let isIncome: Bool
}

class TransactionsViewModel: ObservableObject {
    @Published var transactions: [Transaction] = []

    var totalIncome: Double {
        transactions.filter { $0.isIncome }.map { $0.amount }.reduce(0, +)
    }

    var totalExpense: Double {
        transactions.filter { !$0.isIncome }.map { $0.amount }.reduce(0, +)
    }

    func addTransaction(title: String, amount: Double, isIncome: Bool) {
        let new = Transaction(title: title, amount: amount, date: Date(), isIncome: isIncome)
        transactions.append(new)
    }
}
